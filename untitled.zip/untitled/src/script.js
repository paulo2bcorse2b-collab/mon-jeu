const jokes = [
  "Pourquoi les maths sont tristes ? Parce qu’elles ont trop de problèmes.",
  "Pourquoi les plongeurs plongent-ils toujours en arrière ? Parce que sinon ils tombent dans le bateau.",
  "Que dit une mère à son enfant geek quand le dîner est prêt ? Alt Tab.",
  "Pourquoi dit-on que les programmeurs sont mauvais en danse ? Parce qu’ils ont toujours le mauvais pas.",
  "Pourquoi les fantômes sont mauvais menteurs ? Parce qu’on voit à travers eux.",
  "Que fait un geek quand il a froid ? Il met Windows.",
  "Pourquoi les livres ont-ils toujours chaud ? Parce qu’ils ont une couverture.",
  "Que dit une imprimante dans l’eau ? J’ai papier.",
  "Pourquoi les développeurs aiment le noir ? Parce que la lumière attire les bugs.",
  "Que dit un informaticien quand ça marche ? C’est pas possible.",
  "Pourquoi les squelettes ne se battent jamais ? Ils n’ont pas le cran.",
  "Pourquoi les programmeurs confondent Noël et Halloween ? Parce que OCT 31 = DEC 25.",
  "Que dit une mère à son enfant quand le Wi-Fi est coupé ? Va jouer dehors.",
  "Pourquoi les poissons n’aiment pas Facebook ? Trop de filets.",
  "Pourquoi les développeurs adorent JavaScript ? Parce qu’ils peuvent tout promettre.",
  "Pourquoi les maths adorent Halloween ? À cause des racines carrées.",
  "Pourquoi les ordinateurs détestent la mer ? À cause des virus.",
  "Que dit un codeur quand il est heureux ? Hello World !",
  "Pourquoi les programmeurs aiment le café ? Parce que le code ne compile pas sans lui.",
  "Pourquoi les développeurs détestent les ascenseurs ? Trop de bugs.",
  "Pourquoi les moutons aiment le cloud ? Parce que c’est SaaS.",
  "Que dit un geek à son frigo ? Ferme la porte, j’ai pas faim.",
  "Pourquoi les développeurs sont mauvais en relations ? Ils ont peur de l’engagement.",
  "Pourquoi dit-on que les claviers sont honnêtes ? Parce qu’ils n’ont rien à cacher.",
  "Pourquoi les développeurs aiment la nuit ? Moins de bugs visibles.",
  "Pourquoi les programmeurs aiment les blagues récursives ? Parce qu’ils aiment les blagues récursives.",
  "Pourquoi les ordinateurs éternuent ? À cause des virus.",
  "Pourquoi les développeurs aiment les raccourcis ? Parce qu’ils vont droit au but.",
  "Pourquoi le HTML est mauvais en blagues ? Il est trop balisé.",
  "Pourquoi le CSS est stressé ? Trop de styles à gérer.",
  "Pourquoi Java est fatigué ? Trop de classes.",
  "Pourquoi les développeurs aiment le dark mode ? Parce que la lumière fait mal aux yeux.",
  "Pourquoi Git est mauvais en couple ? Il garde tout en mémoire.",
  "Pourquoi les développeurs aiment les week-ends ? Pour corriger ce qu’ils ont cassé la semaine.",
  "Pourquoi les bugs adorent le code ? Parce qu’ils y vivent gratuitement.",
  "Pourquoi les développeurs aiment les chats ? Parce qu’ils comprennent les claviers.",
  "Pourquoi les ordinateurs sont mauvais en sport ? Trop de RAM.",
  "Pourquoi les développeurs aiment Stack Overflow ? Parce qu’ils ne sont jamais seuls.",
  "Pourquoi les programmeurs aiment les puzzles ? Parce qu’ils aiment déboguer.",
  "Pourquoi le Wi-Fi est triste ? Personne ne se connecte à lui.",
  "Pourquoi les développeurs aiment les listes ? Parce qu’elles sont ordonnées.",
  "Pourquoi les programmeurs aiment les tests ? Pour prouver qu’ils avaient raison.",
  "Pourquoi les développeurs aiment le silence ? Moins d’erreurs.",
  "Pourquoi les ordinateurs aiment Noël ? Pour les cookies.",
  "Pourquoi les développeurs aiment les nuits blanches ? Pour livrer à temps.",
  "Pourquoi les bugs détestent les mises à jour ? Parce qu’elles les suppriment.",
  "Pourquoi les développeurs aiment les blagues nulles ? Parce qu’elles compilent quand même.",
  "Pourquoi le JavaScript est mauvais en maths ? Parce qu’il confond tout.",
  "Pourquoi les développeurs aiment coder ? Parce que c’est logique."
];

const jokeElement = document.getElementById("joke");
const button = document.getElementById("newJoke");

button.addEventListener("click", () => {
  const randomIndex = Math.floor(Math.random() * jokes.length);
  jokeElement.textContent = jokes[randomIndex];
});
const shareButton = document.getElementById("shareJoke");

shareButton.addEventListener("click", () => {
  const jokeText = jokeElement.textContent;

  if (navigator.share) {
    navigator.share({
      title: "Blague 😂",
      text: jokeText
    });
  } else {
    // Fallback si le partage n'est pas supporté
    navigator.clipboard.writeText(jokeText);
    alert("Blague copiée dans le presse-papiers !");
  }
});
const themeToggle = document.getElementById("themeToggle");

// Charger le thème sauvegardé
if (localStorage.getItem("theme") === "light") {
  document.body.classList.add("light");
  themeToggle.textContent = "☀️ Mode clair";
}

themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("light");

  const isLight = document.body.classList.contains("light");

  themeToggle.textContent = isLight
    ? "☀️ Mode clair"
    : "🌙 Mode sombre";

  localStorage.setItem("theme", isLight ? "light" : "dark");
});
const santa = document.querySelector(".santa");

function dropGift() {
  const gift = document.createElement("div");
  gift.classList.add("gift");
  gift.textContent = "🎁";

  // Position du cadeau sous le Père Noël
  const santaRect = santa.getBoundingClientRect();
  gift.style.left = santaRect.left + 40 + "px";

  document.body.appendChild(gift);

  // Supprimer après animation
  setTimeout(() => {
    gift.remove();
  }, 3000);
}

// Lâche un cadeau toutes les 1,5 secondes
setInterval(dropGift, 1500);
